<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

if (isset($_POST['room_type'], $_POST['checkin'], $_POST['checkout'])) {
    $room_type = $_POST['room_type'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];

    $available_count = checkAvailability($room_type, $checkin, $checkout, $pdo);

    // Only send yes/no to the user
    $available = $available_count > 0 ? true : false;

    echo json_encode(['available' => $available]);
}
?>
