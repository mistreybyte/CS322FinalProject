<?php require __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You - Oakland</title>
    <link rel="stylesheet" href="CSS/style.css">
    <!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
                 <nav  class="navbar1" id="mainNavbar">
                <a href="index.html" class="logo">Oakland</a>
               
                <ul class="nav-links">
    <li><a href="index.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Home</a></li>

    <li><a href="about.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">About Us</a></li>

    <li><a href="rooms.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Rooms & Amenities</a></li>

    <li><a href="contact.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Contact</a></li>

</ul>
            </nav>
        </div>
    </header>

    <section style="padding: 160px 0;">
        <div class="container">
            <div style="max-width: 1600px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;">
                <div style="font-size: 4rem; color: var(--accent-color); margin-bottom: 20px;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h1 style="color: var(--navy-blue); margin-bottom: 15px;">Thank You!</h1>
                <p style="font-size: 1.2rem; color: var(--gray); margin-bottom: 30px;">
                    Your booking request has been received successfully.
                </p>
                <p style="margin-bottom: 30px; color: var(--black-color);">
                    We'll contact you within 24 hours to confirm your reservation. 
                    You'll receive an email confirmation shortly.
                </p>
                
                <div style="background: var(--light-color); padding: 25px; border-radius: 8px; margin-bottom: 30px;">
                    <h3 style="color: var(--navy-blue); margin-bottom: 15px;">
                        <i class="fas fa-info-circle" style="margin-right: 8px;"></i>
                        What Happens Next?
                    </h3>
                    <div style="text-align: left; display: inline-block;">
                        <p style="margin: 10px 0;"><i class="fas fa-envelope" style="color: var(--secondary-color); margin-right: 10px;"></i> Email confirmation within 1 hour</p>
                        <p style="margin: 10px 0;"><i class="fas fa-phone" style="color: var(--secondary-color); margin-right: 10px;"></i> Phone confirmation within 24 hours</p>
                        <p style="margin: 10px 0;"><i class="fas fa-credit-card" style="color: var(--secondary-color); margin-right: 10px;"></i> Payment details sent via email</p>
                    </div>
                </div>

                <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                    <a href="index.html" class="btn" style="background: var(--navy-blue);">
                        <i class="fas fa-home" style="margin-right: 8px;"></i>
                        Back to Home
                    </a>
                    <a href="rooms.html" class="btn" style="margin-right: 250px;">
                        <i class="fas fa-bed" style="margin-right: 0px;"></i>
                        View More Rooms
                    </a>
                </div>
            </div>
        </div>
    </section>

     <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>Oakland Guest House</h3>
                    <p>Your home away from home, offering comfort and hospitality in the heart of the city.</p>
                   
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="rooms.html">Rooms & Amenities</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Contact Info</h3>
                    <ul class="footer-links">
                        <li><i class="fas fa-map-marker-alt"></i> Gofa Gebrial </li>
                        <li><i class="fas fa-phone"></i> 0911182829 &nbsp 0943050505</li>
                        <li><i class="fas fa-envelope"></i> Oaklandguesthouse@gmail.com</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Oakland Guest House. All Rights Reserved.</p>
            </div>
        </div>
    </footer>


    <script>
        
    
        // Mobile menu toggle
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');

        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });

        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
            });
        });

        // Add shadow to header on scroll
        window.addEventListener('scroll', () => {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
            } else {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            }
        });
        </script>
    
</body>
</html>