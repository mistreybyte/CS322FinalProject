<?php
// submit.php
// Show errors while you debug locally (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Log errors to a file for debugging
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/hotel_errors.log');

require_once __DIR__ . '/config.php';

// config.php should call session_start() already. If not, uncomment next line:
// if (session_status() === PHP_SESSION_NONE) session_start();

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// Rate limiting (per session, 5 seconds)
if (time() - ($_SESSION['last_booking_time'] ?? 0) < 5) {
    echo "<div style='margin:50px auto; max-width:400px; padding:20px; font-family:sans-serif; color:#721c24; background:#f8d7da; border:1px solid #f5c6cb; border-radius:8px; text-align:center;'>⏳ Please wait 5 seconds before making another booking.</div>";
    exit;
}
$_SESSION['last_booking_time'] = time();

// CSRF check
if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token']) ||
    !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['form_errors']['csrf'] = "Security token expired. Please try again.";
    $_SESSION['form_data'] = $_POST;
    header("Location: booking.php?room_type=" . urlencode($_POST['room_type'] ?? ''));
    exit;
}
// consume token (single-use)
unset($_SESSION['csrf_token']);

// Helper: validate input
function validateBooking(array $data) {
    $errors = [];

    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $room_type = trim($data['room_type'] ?? '');
    $checkin = trim($data['checkin'] ?? '');
    $checkout = trim($data['checkout'] ?? '');
    $requested_at = date('Y-m-d H:i:s');

    // Name
    if ($name === '' || !preg_match('/^[\p{L}\s\'\-\.]{2,100}$/u', $name)) {
        $errors['name'] = 'Invalid name (2-100 letters allowed).';
    }
    // Email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email address.';
    }
    // Phone
    if (!preg_match('/^[0-9+\-\s\(\)]{6,30}$/', $phone)) {
        $errors['phone'] = 'Invalid phone number.';
    }
    // Dates
    if ($checkin === '' || $checkout === '') {
        $errors['dates'] = 'Please select both check-in and check-out dates.';
    } else {
        try {
            $checkin_dt = new DateTime($checkin);
            $checkout_dt = new DateTime($checkout);
            $today = new DateTime('today');
            if ($checkin_dt < $today) {
                $errors['checkin'] = 'Check-in date cannot be in the past.';
            }
            if ($checkout_dt <= $checkin_dt) {
                $errors['checkout'] = 'Check-out must be after check-in.';
            }
        } catch (Exception $e) {
            $errors['dates'] = 'Invalid date format.';
        }
    }

    return [
        'ok' => empty($errors),
        'errors' => $errors,
        'clean' => [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'room_type' => $room_type,
            'checkin' => $checkin,
            'checkout' => $checkout,
            'requested_at' => $requested_at
        ]
    ];
}

// Validate input
$validation = validateBooking($_POST);
if (!$validation['ok']) {
    $_SESSION['form_errors'] = $validation['errors'];
    $_SESSION['form_data'] = $_POST;
    header("Location: booking.php?room_type=" . urlencode($_POST['room_type'] ?? ''));
    exit;
}
$clean = $validation['clean'];

function checkAvailability($room_type, $checkin, $checkout, $pdo) {
    // Get total rooms for this type
    $stmt = $pdo->prepare("SELECT total_rooms FROM rooms WHERE room_type = :room_type");
    $stmt->execute([':room_type' => $room_type]);
    $room = $stmt->fetch();
    $total = $room['total_rooms'];

    // Count overlapping bookings
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as booked 
        FROM bookings 
        WHERE room_type = :room_type
        AND (checkin < :checkout AND checkout > :checkin)
    ");
    $stmt->execute([
        ':room_type' => $room_type,
        ':checkin' => $checkin,
        ':checkout' => $checkout
    ]);
    $booked = $stmt->fetchColumn();

    return $total - $booked;
}



// Insert booking into database - capture execute result correctly
try {
    $stmt = $pdo->prepare("INSERT INTO bookings (room_type, name, phone, email, checkin, checkout, requested_at) VALUES (:room_type, :name, :phone, :email, :checkin, :checkout, :requested_at)");
    $result = $stmt->execute([
        ':room_type' => $clean['room_type'],
        ':name'      => $clean['name'],
        ':phone'     => $clean['phone'],
        ':email'     => $clean['email'],
        ':checkin'   => $clean['checkin'],
        ':checkout'  => $clean['checkout'],
        ':requested_at' => $clean['requested_at']
    ]);

    // check success properly
    if ($result && $stmt->rowCount() >= 0) {
        $insertedId = $pdo->lastInsertId();
        error_log("Booking inserted successfully! ID: $insertedId");
    } else {
        error_log("Booking insertion failed - execute returned false or 0 rows.");
        throw new Exception('DB insert failed');
    }
} catch (Exception $e) {
    error_log("DB insert failed: " . $e->getMessage());
    $_SESSION['form_errors']['database'] = 'An internal error occurred. Please try again later.';
    $_SESSION['form_data'] = $_POST;
    header("Location: booking.php?room_type=" . urlencode($clean['room_type']));
    exit;
}

// Optional: send email notification (silent failures ok)
$admin_email = $admin_email ?? 'yourname@yourdomain.com';
$subject = "New Booking (#{$insertedId}) - {$clean['room_type']}";
$message = "New booking received:\n\nRoom: {$clean['room_type']}\nName: {$clean['name']}\nPhone: {$clean['phone']}\nEmail: {$clean['email']}\nRequested at: {$clean['requested_at']}\nSubmitted at: " . date('Y-m-d H:i:s') . "\n";
$headers = "From: no-reply@yourdomain.com\r\nReply-To: {$clean['email']}\r\nX-Mailer: PHP/".phpversion();
@mail($admin_email, $subject, $message, $headers);

// Success - redirect to thank-you
header('Location: thanks.php');
exit;
