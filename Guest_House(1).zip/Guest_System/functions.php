<?php


/**
 * Check how many rooms of a given type are available between two dates
 */
function checkAvailability(string $room_type, string $checkin, string $checkout, PDO $pdo): int
{
    // Basic guard
    if (!$room_type || !$checkin || !$checkout) return 0;

    // 1) Get total rooms for that room type
    $stmt = $pdo->prepare("SELECT total_rooms FROM rooms WHERE room_type = ?");
    $stmt->execute([$room_type]);
    $room = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$room) return 0;
    $total_rooms = (int)$room['total_rooms'];

    // 2) Count bookings that overlap with the requested interval
    // Overlap test: NOT (existing.checkout <= requested.checkin OR existing.checkin >= requested.checkout)
    $sql = "
        SELECT COUNT(*) AS booked_count
        FROM bookings
        WHERE room_type = ?
          AND NOT (checkout <= ? OR checkin >= ?)
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$room_type, $checkin, $checkout]);
    $booked = (int)$stmt->fetchColumn();

    $available = $total_rooms - $booked;
    return max($available, 0);
}

/**
 * sanitize() - simple input sanitiser for output
 */
function sanitize(string $input): string
{
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Function to store and retrieve flash messages (like success/error notifications)
 */
function setFlash($key, $message)
{
    $_SESSION['flash'][$key] = $message;
}

function getFlash($key)
{
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return '';
}
?>
