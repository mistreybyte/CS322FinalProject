<?php
require_once __DIR__ . '/../config.php';      // from admin folder to project root
require_once __DIR__ . '/../functions.php';

$checkin = $_POST['checkin'] ?? '';
$checkout = $_POST['checkout'] ?? '';

$response = [];
$stmt = $pdo->query("SELECT room_type FROM rooms");
$rooms = $stmt->fetchAll();

foreach ($rooms as $room) {
    $available = checkAvailability($room['room_type'], $checkin, $checkout, $pdo);
    $response[$room['room_type']] = $available;
}

echo json_encode($response);
?>
