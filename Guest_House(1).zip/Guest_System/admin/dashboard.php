<?php
require_once __DIR__ . '/../config.php';      // from admin folder to project root
require_once __DIR__ . '/../functions.php';

// Admin guard: check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../secure_login.php");
    exit;
}

// Fetch all bookings with checkin/checkout dates
$stmt = $pdo->query("SELECT id, room_type, name, phone, email, checkin, checkout, requested_at FROM bookings ORDER BY id DESC");
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Oakland</title>
  <link rel="stylesheet" href="../CSS/style.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    /* Admin Navbar Styling - Same as main site */

    .admin-dashboard-section {
        padding: 100px 0;
        background: linear-gradient(135deg, var(--white-color) 0%, var(--gray-color) 100%);
        min-height: 100vh;
        padding-top: 200px;
    }

    .dashboard-card {
        background: var(--white-color);
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        position: relative;
    }

    .dashboard-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, var(--accent-color), var(--secondary-color));
        border-radius: 20px 20px 0 0;
    }

    .dashboard-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }

    .dashboard-title {
        font-size: 2.5rem;
        font-weight: 700;
        color: var(--primary-color);
        font-family: 'Playfair Display', serif;
    }

    .bookings-table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        background: var(--white-color);
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
    }

    .bookings-table th,
    .bookings-table td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid var(--border-color);
    }

    .bookings-table th {
        background: var(--primary-color);
        color: var(--white-color);
        font-weight: 600;
        font-family: 'Montserrat', sans-serif;
    }

    .bookings-table tr:hover {
        background: var(--gray-color);
    }

    .room-badge {
        background: var(--secondary-color);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 0.8rem;
        font-weight: 600;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--black-color);
        opacity: 0.7;
    }

    .booking-stats {
        margin-top: 20px;
        padding: 15px;
        background: var(--gray-color);
        border-radius: 8px;
        text-align: center;
    }

    .btn {
        padding: 10px 20px;
        background: var(--primary-color);
        color: white;
        text-decoration: none;
        border-radius: 5px;
        margin-left: 10px;
    }
    .btn:hover {
        background: var(--secondary-color);
    transform: translateY(-2px);
    }
  </style>
</head>
<body>
    <header>
        <div class="container">
                      <nav  class="navbar1" id="mainNavbar">
                <a href="index.html" class="logo">Oakland</a>
               
                <ul class="nav-links">
    <li><a href="dashboard.php" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Dashboard</a></li>

    <li><a href="admin_bookings.php" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Book</a></li>

    <li><a href="logout.php" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Logout</a></li>


</ul>
            </nav>
        </div>
    </header>

    <section class="admin-dashboard-section">
        <div class="container">
            <div class="dashboard-card">
                <div class="dashboard-header">
                    <h1 class="dashboard-title">Booking Requests</h1>
                    <div class="dashboard-actions">
                        <a href="logout.php" class="btn">Logout</a>
                        <a href="dashboard.php" class="btn">Refresh</a>
                    </div>
                </div>

                <?php if (empty($bookings)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No bookings yet</h3>
                        <p>When guests make bookings, they will appear here.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="bookings-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Room Type</th>
                                    <th>Guest Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Check-in</th>
                                    <th>Check-out</th>
                                    <th>Requested At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bookings as $b): ?>
                                    <tr>
                                        <td><?= (int)$b['id'] ?></td>
                                        <td><span class="room-badge"><?= htmlspecialchars($b['room_type']) ?></span></td>
                                        <td><?= htmlspecialchars($b['name']) ?></td>
                                        <td><?= htmlspecialchars($b['phone']) ?></td>
                                        <td><a href="mailto:<?= htmlspecialchars($b['email']) ?>"><?= htmlspecialchars($b['email']) ?></a></td>
                                        <td><?= htmlspecialchars($b['checkin']) ?></td>
                                        <td><?= htmlspecialchars($b['checkout']) ?></td>
                                        <td><?= htmlspecialchars($b['requested_at']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="booking-stats">
                        <p>Total Bookings: <strong><?= count($bookings) ?></strong></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
</body>
</html>