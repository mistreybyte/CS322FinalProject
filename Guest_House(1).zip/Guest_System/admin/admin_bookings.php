<?php
require_once __DIR__ . '/../config.php';      // from admin folder to project root
require_once __DIR__ . '/../functions.php';

// Admin authentication
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$isAdmin = true; // replace with real auth
if (!$isAdmin) die("Access denied");

// ====== START PRG FORM HANDLING ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $room_type = $_POST['room_type'] ?? '';
    $checkin = $_POST['checkin'] ?? '';
    $checkout = $_POST['checkout'] ?? '';

    $errors = [];

    // Field validation
    if (empty($name)) $errors['name'] = "Name is required.";
    if (empty($phone)) $errors['phone'] = "Phone is required.";
    if (empty($email)) $errors['email'] = "Email is required.";
    if (empty($room_type)) $errors['room_type'] = "Room type is required.";
    if (empty($checkin)) $errors['checkin'] = "Check-in date is required.";
    if (empty($checkout)) $errors['checkout'] = "Check-out date is required.";

    // Date validation
    if (empty($errors)) {
        if (new DateTime($checkin) >= new DateTime($checkout)) {
            $errors['checkout'] = "Check-out must be after check-in.";
        }
    }

    // Availability check
    if (empty($errors) && !empty($room_type)) {
        $available = checkAvailability($room_type, $checkin, $checkout, $pdo);
        if ($available <= 0) {
            $errors['room_type'] = "No $room_type rooms available for selected dates.";
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO bookings (room_type, name, phone, email, checkin, checkout, requested_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$room_type, $name, $phone, $email, $checkin, $checkout]);
        $_SESSION['admin_success'] = "Booking added successfully! ";
    } else {
        $_SESSION['admin_errors'] = $errors;
        $_SESSION['admin_form_data'] = $_POST;
    }

    // Redirect to same page to avoid form resubmission
    header("Location: admin_bookings.php");
    exit;
}
// ====== END PRG FORM HANDLING ======

$errors = $_SESSION['admin_errors'] ?? [];
$success = $_SESSION['admin_success'] ?? '';
$form_data = $_SESSION['admin_form_data'] ?? [];
unset($_SESSION['admin_errors'], $_SESSION['admin_success'], $_SESSION['admin_form_data']);

// Fetch all rooms
$stmt = $pdo->query("SELECT * FROM rooms");
$rooms = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Booking Dashboard - Oakland Hotel</title>
  <link rel="stylesheet" href="../CSS/style.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
.admin-dashboard {
    padding: 80px 0;
    background: linear-gradient(135deg, var(--white-color) 0%, var(--gray-color) 100%);
    min-height: 100vh;
}

.admin-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.dashboard-header {
    text-align: center;
    margin-bottom: 10px;
    padding: 60px;
}

.dashboard-title {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 0px;
    font-family: 'Playfair Display', serif;
    padding: 20px;
    margin-left: 70px;
}

.dashboard-subtitle {
    font-size: 1.1rem;
    color: var(--black-color);
    opacity: 0.8;
}

/* Cards */
.dashboard-card {
    background: var(--white-color);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    margin-bottom: 40px;
    position: relative;
}

.dashboard-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--accent-color), var(--secondary-color));
    border-radius: 20px 20px 0 0;
}

/* Forms */
.form-group {
    position: relative;
    margin-bottom: 25px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: var(--primary-color);
    font-family: 'Montserrat', sans-serif;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 1rem;
    transition: all 0.3s ease;
    font-family: 'Roboto', sans-serif;
}

.form-group input:focus,
.form-group select:focus {
    border-color: var(--secondary-color);
    outline: none;
    box-shadow: 0 0 0 3px rgba(58, 124, 165, 0.1);
}

.form-group input.error,
.form-group select.error {
    border-color: #dc2626;
    background-color: #fef2f2;
}

.error-tooltip {
    position: absolute;
    top: 100%;
    left: 0;
    background: #dc2626;
    color: white;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 0.875rem;
    margin-top: 4px;
    z-index: 10;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    white-space: nowrap;
}

.error-tooltip::before {
    content: '';
    position: absolute;
    top: -6px;
    left: 15px;
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-bottom: 6px solid #dc2626;
}

/* Tables */
.availability-table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background: var(--white-color);
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
}

.availability-table th,
.availability-table td {
    padding: 15px;
    text-align: center;
    border-bottom: 1px solid var(--border-color);
}

.availability-table th {
    background: var(--primary-color);
    color: var(--white-color);
    font-weight: 600;
    font-family: 'Montserrat', sans-serif;
}

.availability-table tr:last-child td {
    border-bottom: none;
}

.availability-table tr:hover {
    background: var(--gray-color);
}

/* Buttons */
.submit-btn {
    background: var(--primary-color);
    color: var(--white-color);
    border: none;
    padding: 15px 30px;
    border-radius: 10px;
    font-size: 1rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-family: 'Montserrat', sans-serif;
    width: 100%;
}

.submit-btn:hover {
    background: var(--secondary-color);
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(10, 36, 99, 0.3);
}

/* Messages */
.success-message {
    background: #10B981;
    color: white;
    padding: 15px 20px;
    border-radius: 8px;
    margin: 20px 0;
    text-align: center;
    font-weight: 500;
}

.error-message {
    background: #dc2626;
    color: white;
    padding: 15px 20px;
    border-radius: 8px;
    margin: 20px 0;
    text-align: center;
    font-weight: 500;
}

/* Form Layout */
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-full {
    grid-column: 1 / -1;
}

/* Section Headers */
.section-title {
    font-size: 1.8rem;
    font-weight: 600;
    color: var(--primary-color);
    margin-bottom: 25px;
    font-family: 'Playfair Display', serif;
}

.section-subtitle {
    font-size: 1.3rem;
    font-weight: 500;
    color: var(--primary-color);
    margin: 30px 0 20px 0;
}

/* Responsive */
@media (max-width: 768px) {
    .admin-dashboard {
        padding: 60px 0;
    }
    
    .dashboard-card {
        padding: 25px 20px;
    }
    
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .dashboard-title {
        font-size: 2rem;
    }
    
    .section-title {
        font-size: 1.5rem;
    }
    
    .availability-table {
        font-size: 0.9rem;
    }
    
    .availability-table th,
    .availability-table td {
        padding: 10px 8px;
    }
}
</style>
</head>
<body>
     <header>
        <div class="container">
                     <nav  class="navbar1" id="mainNavbar">
                <a href="index.html" class="logo">Oakland</a>
               
                <ul class="nav-links">
    <li><a href="dashboard.php" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Dashboard</a></li>

    <li><a href="admin_bookings.php" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Book</a></li>

    <li><a href="logout.php" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Logout</a></li>


</ul>
            </nav>
        </div>
    </header>

    <section class="admin-dashboard">
        <div class="admin-container">
            <div class="dashboard-header">
                <h1 class="dashboard-title">Admin Booking Dashboard</h1>
                <p class="dashboard-subtitle">Manage room availability and bookings</p>
            </div>

            <!-- Check Availability Card -->
            <div class="dashboard-card">
                <h2 class="section-title">Check Room Availability</h2>
                <form id="availability-form" class="form-grid">
                    <div class="form-group">
                        <label>Check-in Date</label>
                        <input type="date" name="checkin" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Check-out Date</label>
                        <input type="date" name="checkout" value="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                    </div>
                </form>

                <h3 class="section-subtitle">Room Availability</h3>
                <table class="availability-table">
                    <tr>
                        <th>Room Type</th>
                        <th>Total Rooms</th>
                        <th>Available</th>
                    </tr>
                    <?php foreach($rooms as $room): ?>
                    <tr data-room="<?= htmlspecialchars($room['room_type']) ?>">
                        <td><?= htmlspecialchars($room['room_type']) ?></td>
                        <td><?= $room['total_rooms'] ?></td>
                        <td class="available">--</td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>

            <!-- Add Booking Card -->
            <div class="dashboard-card">
                <h2 class="section-title">Add New Booking</h2>
                
                <?php if ($success): ?>
                    <div class="success-message"><?= htmlspecialchars($success) ?></div>
                <?php endif; ?>

                <form method="POST" action="admin_bookings.php" class="form-grid">
                    <div class="form-group">
                        <label>Guest Name</label>
                        <input type="text" 
                               name="name" 
                               value="<?= htmlspecialchars($form_data['name'] ?? '') ?>" 
                               class="<?= isset($errors['name']) ? 'error' : '' ?>"
                               required>
                        <?php if (isset($errors['name'])): ?>
                            <div class="error-tooltip">
                                <?= htmlspecialchars($errors['name']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" 
                               name="phone" 
                               value="<?= htmlspecialchars($form_data['phone'] ?? '') ?>" 
                               class="<?= isset($errors['phone']) ? 'error' : '' ?>"
                               required>
                        <?php if (isset($errors['phone'])): ?>
                            <div class="error-tooltip">
                                <?= htmlspecialchars($errors['phone']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" 
                               name="email" 
                               value="<?= htmlspecialchars($form_data['email'] ?? '') ?>" 
                               class="<?= isset($errors['email']) ? 'error' : '' ?>"
                               required>
                        <?php if (isset($errors['email'])): ?>
                            <div class="error-tooltip">
                                <?= htmlspecialchars($errors['email']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Room Type</label>
                        <select name="room_type" 
                                class="<?= isset($errors['room_type']) ? 'error' : '' ?>"
                                required>
                            <option value="">Select Room Type</option>
                            <?php foreach($rooms as $room): ?>
                            <option value="<?= htmlspecialchars($room['room_type']) ?>" 
                                <?= (isset($form_data['room_type']) && $form_data['room_type'] === $room['room_type']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($room['room_type']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (isset($errors['room_type'])): ?>
                            <div class="error-tooltip">
                                <?= htmlspecialchars($errors['room_type']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Check-in Date</label>
                        <input type="date" 
                               name="checkin" 
                               value="<?= htmlspecialchars($form_data['checkin'] ?? date('Y-m-d')) ?>" 
                               class="<?= isset($errors['checkin']) ? 'error' : '' ?>"
                               required>
                        <?php if (isset($errors['checkin'])): ?>
                            <div class="error-tooltip">
                                <?= htmlspecialchars($errors['checkin']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Check-out Date</label>
                        <input type="date" 
                               name="checkout" 
                               value="<?= htmlspecialchars($form_data['checkout'] ?? date('Y-m-d', strtotime('+1 day'))) ?>" 
                               class="<?= isset($errors['checkout']) ? 'error' : '' ?>"
                               required>
                        <?php if (isset($errors['checkout'])): ?>
                            <div class="error-tooltip">
                                <?= htmlspecialchars($errors['checkout']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-full">
                        <button type="submit" class="submit-btn">Add Booking</button>
                    </div>
                </form>
            </div>
        </div>
    </section>

<script>
// AJAX availability check
function fetchAvailability() {
    const form = document.getElementById('availability-form');
    const checkin = form.checkin.value;
    const checkout = form.checkout.value;

    fetch('ajax_check_availability.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `checkin=${checkin}&checkout=${checkout}`
    })
    .then(res => res.json())
    .then(data => {
        for (const roomType in data) {
            const row = document.querySelector(`tr[data-room="${roomType}"] .available`);
            if (row) {
                if (data[roomType] > 0) {
                    row.textContent = data[roomType];
                    row.style.color = '#10B981';
                    row.style.fontWeight = '600';
                } else {
                    row.textContent = 'Fully booked';
                    row.style.color = '#dc2626';
                    row.style.fontWeight = '600';
                }
            }
        }
    });
}

// Fetch on page load
fetchAvailability();

// Fetch when dates change
document.querySelectorAll('#availability-form input').forEach(input => {
    input.addEventListener('change', fetchAvailability);
});

// Remove error class when user starts typing
document.querySelectorAll('input, select').forEach(field => {
    field.addEventListener('input', function() {
        this.classList.remove('error');
        const tooltip = this.parentNode.querySelector('.error-tooltip');
        if (tooltip) tooltip.remove();
    });
    
    field.addEventListener('change', function() {
        this.classList.remove('error');
        const tooltip = this.parentNode.querySelector('.error-tooltip');
        if (tooltip) tooltip.remove();
    });
});
</script>
</body>
</html>