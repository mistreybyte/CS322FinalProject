<?php
require_once __DIR__ . '/../config.php';      // from admin folder to project root
require_once __DIR__ . '/../functions.php';

// Admin authentication
$isAdmin = true; // replace with real auth
if (!$isAdmin) die("Access denied");

// ====== START PRG FORM HANDLING ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $room_type = $_POST['room_type'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];

    $errors = [];

    // Basic validation
    if (!$name || !$phone || !$email || !$room_type || !$checkin || !$checkout) {
        $errors[] = "All fields are required.";
    }
    if (new DateTime($checkin) >= new DateTime($checkout)) {
        $errors[] = "Check-out must be after check-in.";
    }

   $available = checkAvailability($room_type, $checkin, $checkout, $pdo);
if ($available <= 0) {
    $booking_message = "<p style='color:red'>❌ Room type not available for these dates.</p>";
} else {
    $stmt = $pdo->prepare("INSERT INTO bookings (room_type, name, phone, email, checkin, checkout, requested_at)
                           VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$room_type, $name, $phone, $email, $checkin, $checkout]);
    $booking_message = "<p style='color:green'>✅ Booking added successfully!</p>";
}

    // Redirect to same page to avoid form resubmission
    header("Location: admin_bookings.php");
    exit;
}
// ====== END PRG FORM HANDLING ======