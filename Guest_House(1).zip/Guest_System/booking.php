<?php
// booking.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

// config.php calls session_start(); if it doesn't, ensure session is started:
// if (session_status() === PHP_SESSION_NONE) session_start();

// Load flash/errors/form data
$errors = $_SESSION['form_errors'] ?? [];
$form_data = $_SESSION['form_data'] ?? [];
$success = $_SESSION['user_success'] ?? '';
unset($_SESSION['form_errors'], $_SESSION['form_data'], $_SESSION['user_success']);

// Fetch all rooms early (so we can default a room_type)
$stmt = $pdo->query("SELECT * FROM rooms");
$rooms = $stmt->fetchAll();

// Determine $room_type for the form/title:
// priority: GET param (if used), else from posted form_data, else first room type in DB, else empty.
$room_type = '';
if (isset($_GET['room_type']) && trim($_GET['room_type']) !== '') {
    $room_type = trim($_GET['room_type']);
} elseif (!empty($form_data['room_type'])) {
    $room_type = $form_data['room_type'];
} elseif (!empty($rooms)) {
    // use first room_type as fallback so title isn't "Book a "
    $room_type = $rooms[0]['room_type'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book a room - Oakland</title>
  <link rel="stylesheet" href="CSS/style.css">
  <!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

  <header>
    <div class="container">
        <nav  class="navbar1" id="mainNavbar">
                <a href="index.html" class="logo">Oakland</a>
               
                <ul class="nav-links">
    <li><a href="index.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Home</a></li>

    <li><a href="about.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">About Us</a></li>

    <li><a href="rooms.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Rooms & Amenities</a></li>

    <li><a href="contact.html" style="color:#ffffff;" 
        onmouseover="this.style.color=' rgba(40, 150, 214)'" 
        onmouseout="this.style.color='#ffffff'">Contact</a></li>

</ul>
            </nav>
    </div>
  </header>

  <section class="booking-section" style="padding:160px 0;">
    <div class="container">
      <div class="booking-card">
        <h1 class="booking-title">Book a Room</h1>

        <!-- show top-level errors (if any) -->
        <?php if (!empty($errors) && isset($errors['database'])): ?>
          <div class="error-message"><?= htmlspecialchars($errors['database']) ?></div>
        <?php endif; ?>

        <form action="submit.php" method="post" class="booking-form" novalidate>
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
<input type="hidden" name="room_type" id="room_type" value="<?= htmlspecialchars($room_type) ?>">

            <div class="form-group">
                        <label>Room Type</label>
                        <select name="room_type" 
                                class="<?= isset($errors['room_type']) ? 'error' : '' ?>"
                                required>
                            <option value="">Select Room Type</option>
                            <?php foreach($rooms as $room): ?>
                            <option value="<?= htmlspecialchars($room['room_type']) ?>" 
                                <?= (isset($form_data['room_type']) && $form_data['room_type'] === $room['room_type']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($room['room_type']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (isset($errors['room_type'])): ?>
                            <div class="error-tooltip">
                                <?= htmlspecialchars($errors['room_type']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
          <div class="form-group">
            <label for="name">Full Name</label>
            <input id="name" name="name" value="<?= htmlspecialchars($form_data['name'] ?? '') ?>" required
                   class="<?= isset($errors['name']) ? 'error' : '' ?>">
            <?php if (isset($errors['name'])): ?>
              <div class="error-tooltip"><?= htmlspecialchars($errors['name']) ?></div>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label for="phone">Phone</label>
            <input id="phone" name="phone" value="<?= htmlspecialchars($form_data['phone'] ?? '') ?>" required
                   class="<?= isset($errors['phone']) ? 'error' : '' ?>">
            <?php if (isset($errors['phone'])): ?>
              <div class="error-tooltip"><?= htmlspecialchars($errors['phone']) ?></div>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" value="<?= htmlspecialchars($form_data['email'] ?? '') ?>" required
                   class="<?= isset($errors['email']) ? 'error' : '' ?>">
            <?php if (isset($errors['email'])): ?>
              <div class="error-tooltip"><?= htmlspecialchars($errors['email']) ?></div>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label for="checkin">Check-in</label>
            <input id="checkin" name="checkin" type="date" value="<?= htmlspecialchars($form_data['checkin'] ?? '') ?>" required
                   class="<?= isset($errors['checkin']) ? 'error' : '' ?>">
            <?php if (isset($errors['checkin'])): ?>
              <div class="error-tooltip"><?= htmlspecialchars($errors['checkin']) ?></div>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label for="checkout">Check-out</label>
            <input id="checkout" name="checkout" type="date" value="<?= htmlspecialchars($form_data['checkout'] ?? '') ?>" required
                   class="<?= isset($errors['checkout']) ? 'error' : '' ?>">
            <?php if (isset($errors['checkout'])): ?>
              <div class="error-tooltip"><?= htmlspecialchars($errors['checkout']) ?></div>
            <?php endif; ?>
          </div>

          


          <div class="form-submit">
            
            <button type="submit" class="btn booking-btn">
              <i class="fas fa-calendar-check"></i> Submit Booking Request
            </button>
          </div>

          <div id="availability-msg" style="margin-top:10px;"></div>
        </form>

        <div class="booking-info">
          <h3><i class="fas fa-concierge-bell"></i> Booking Information</h3>
          <p><strong>Confirmation:</strong> You'll receive an email confirmation</p>
          <p><strong>Cancellation:</strong> Free cancellation up to 2 hours before checkin</p>
        </div>
      </div>
    </div>
  </section>
   <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>Oakland Guest House</h3>
                    <p>Your home away from home, offering comfort and hospitality in the heart of the city.</p>
                   
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="rooms.html">Rooms & Amenities</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Contact Info</h3>
                    <ul class="footer-links">
                        <li><i class="fas fa-map-marker-alt"></i> Gofa Gebrial </li>
                        <li><i class="fas fa-phone"></i> 0911182829 &nbsp 0943050505</li>
                        <li><i class="fas fa-envelope"></i> Oaklandguesthouse@gmail.com</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Oakland Guest House. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
  <script>
    // Remove error class when user starts typing
document.querySelectorAll('input, select, textarea').forEach(field => {
    field.addEventListener('input', function() {
        this.classList.remove('error');
        const tooltip = this.parentNode.querySelector('.error-tooltip');
        if (tooltip) tooltip.remove();
    });
    
    field.addEventListener('change', function() {
        this.classList.remove('error');
        const tooltip = this.parentNode.querySelector('.error-tooltip');
        if (tooltip) tooltip.remove();
    });
});

  
    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function() {
                navLinks.classList.toggle('active');
                
                // Toggle icon
                const icon = menuToggle.querySelector('i');
                if (navLinks.classList.contains('active')) {
                    icon.classList.remove('fa-bars');
                    icon.classList.add('fa-times');
                } else {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            });
            
            // Close menu when clicking links
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    const icon = menuToggle.querySelector('i');
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                });
            });
        }

        // Add shadow to header on scroll
        window.addEventListener('scroll', () => {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
            } else {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            }
        });
    });
// availability button JS
    document.getElementById('check-availability-btn').addEventListener('click', function(e) {
      e.preventDefault();
      const room_type = document.getElementById('room_type').value;
      const checkin = document.getElementById('checkin').value;
      const checkout = document.getElementById('checkout').value;
      const msgBox = document.getElementById('availability-msg');

      if (!room_type || !checkin || !checkout) {
        msgBox.style.color = 'red';
        msgBox.textContent = 'Please select room type and dates first.';
        return;
      }

      fetch('check_availability.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `room_type=${encodeURIComponent(room_type)}&checkin=${encodeURIComponent(checkin)}&checkout=${encodeURIComponent(checkout)}`
      })
      .then(res => res.json())
      .then(data => {
        if (data.available) {
          msgBox.style.color = 'green'; msgBox.textContent = 'Available';
        } else {
          msgBox.style.color = 'red'; msgBox.textContent = 'Not Available';
        }
      })
      .catch(err => {
        console.error(err);
        msgBox.style.color = 'red'; msgBox.textContent = 'Error checking availability';
      });
    });
  </script>
  <style>
.form-group {
    position: relative;
    margin-bottom: 25px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: var(--primary-color);
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 1rem;
    transition: all 0.3s ease;
    font-family: inherit;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: var(--secondary-color);
    outline: none;
    box-shadow: 0 0 0 3px rgba(58, 124, 165, 0.1);
}

.form-group input.error,
.form-group select.error,
.form-group textarea.error {
    border-color: #dc2626;
    background-color: #fef2f2;
}

.error-tooltip {
    position: absolute;
    top: 100%;
    left: 0;
    background: #dc2626;
    color: white;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 0.875rem;
    margin-top: 4px;
    z-index: 10;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    white-space: nowrap;
}

.error-tooltip::before {
    content: '';
    position: absolute;
    top: -6px;
    left: 15px;
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-bottom: 6px solid #dc2626;
}

.submit-btn {
    width: 100%;
    background: var(--primary-color);
    color: var(--white-color);
    border: none;
    padding: 15px 30px;
    border-radius: 10px;
    font-size: 1.1rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.submit-btn:hover {
    background: var(--primary-600);
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(10, 36, 99, 0.3);
}
</style>
</body>
</html>