<?php
require __DIR__ . '/config.php';

// near top of booking.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
session_start();
$errors = $_SESSION['form_errors'] ?? [];
$form_data = $_SESSION['form_data'] ?? [];
unset($_SESSION['form_errors'], $_SESSION['form_data']);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$room_type = $_GET['room_type'] ?? '';
if ($room_type === '') {
    header("Location: index.html");
    exit;
}
$_SESSION['last_booking_time'] = time();
// Ensure a room type was selected
$room_type = isset($_GET['room_type']) ? trim($_GET['room_type']) : '';
if ($room_type === '') {
    header('Location: index.html'); 
    exit;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book a <?= htmlspecialchars($room_type) ?> - Oakland</title>
  <link rel="stylesheet" href="CSS/style.css">
  <!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

  <header>
    <div class="container">
        <nav>
            <a href="index.html" class="logo">Oakland</a>
            <div class="menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
            <ul class="nav-links">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="rooms.html">Rooms & Amenities</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </nav>
    </div>
  </header>
<input type="hidden" name="room_type" value="<?= htmlspecialchars($room_type) ?>">
  <section style="padding: 160px 0 160px;"class="booking-section">
    <div class="container">
        <div class="booking-card">
            <h1 class="booking-title">Book a <?= htmlspecialchars($room_type) ?> Room</h1>
            <p class="booking-subtitle">Complete the form below to request your booking</p>

          <form action="submit.php" method="post" class="booking-form">
    <!-- Hidden values -->
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
    <input type="hidden" name="room_type" value="<?= htmlspecialchars($room_type) ?>">

    <div class="form-row">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input id="name" name="name" type="text" required maxlength="100" class="form-input">
        </div>

        <div class="form-group">
            <label for="phone">Phone Number</label>
            <input id="phone" name="phone" type="text" required maxlength="30" class="form-input">
        </div>
    </div>

    <div class="form-group">
        <label for="email">Email Address</label>
        <input id="email" name="email" type="email" required maxlength="150" class="form-input">
    </div>

    <div class="form-group">
        <label for="requested_at">Preferred Check-in Date & Time</label>
        <input id="requested_at" name="requested_at" type="datetime-local" required class="form-input">
    </div>

    <div class="form-submit">
        <button type="submit" class="btn booking-btn">
            <i class="fas fa-calendar-check"></i>
            Submit Booking Request
        </button>
    </div>
</form>


            <div class="booking-info">
                <h3>
                    <i class="fas fa-concierge-bell"></i>
                    Booking Information
                </h3>
                <p><strong>Room Type:</strong> <?= htmlspecialchars($room_type) ?></p>
                <p><strong>Confirmation:</strong> You'll receive an email confirmation</p>
                <p><strong>Cancellation:</strong> Free cancellation up to 24 hours before check-in</p>
            </div>
        </div>
    </div>
  </section>
  <form method="post" action="submit.php">
    <!-- Name Field -->
    <div class="form-group">
        <label for="name">Full Name</label>
        <input type="text" 
               name="name" 
               id="name"
               value="<?php echo htmlspecialchars($form_data['name'] ?? ''); ?>"
               class="<?php echo isset($errors['name']) ? 'error' : ''; ?>"
               required>
        <?php if (isset($errors['name'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['name']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Email Field -->
    <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" 
               name="email" 
               id="email"
               value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>"
               class="<?php echo isset($errors['email']) ? 'error' : ''; ?>"
               required>
        <?php if (isset($errors['email'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['email']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Phone Field -->
    <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="tel" 
               name="phone" 
               id="phone"
               value="<?php echo htmlspecialchars($form_data['phone'] ?? ''); ?>"
               class="<?php echo isset($errors['phone']) ? 'error' : ''; ?>"
               required>
        <?php if (isset($errors['phone'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['phone']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Room Type Field -->
    <div class="form-group">
        <label for="room_type">Room Type</label>
        <select name="room_type" 
                id="room_type"
                class="<?php echo isset($errors['room_type']) ? 'error' : ''; ?>"
                required>
            <option value="">Select Room Type</option>
            <option value="Deluxe" <?php echo (isset($form_data['room_type']) && $form_data['room_type'] === 'Deluxe') ? 'selected' : ''; ?>>Deluxe Room</option>
            <option value="Standard" <?php echo (isset($form_data['room_type']) && $form_data['room_type'] === 'Standard') ? 'selected' : ''; ?>>Standard Room</option>
            <option value="Suite" <?php echo (isset($form_data['room_type']) && $form_data['room_type'] === 'Suite') ? 'selected' : ''; ?>>Suite</option>
            <option value="Family" <?php echo (isset($form_data['room_type']) && $form_data['room_type'] === 'Family') ? 'selected' : ''; ?>>Family Room</option>
            <option value="Double" <?php echo (isset($form_data['room_type']) && $form_data['room_type'] === 'Double') ? 'selected' : ''; ?>>Double Bed Room</option>
        </select>
        <?php if (isset($errors['room_type'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['room_type']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Check-in Date -->
    <div class="form-group">
        <label for="checkin">Check-in Date</label>
        <input type="date" 
               name="checkin" 
               id="checkin"
               value="<?php echo htmlspecialchars($form_data['checkin'] ?? ''); ?>"
               class="<?php echo isset($errors['checkin']) ? 'error' : ''; ?>"
               required>
        <?php if (isset($errors['checkin'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['checkin']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Check-out Date -->
    <div class="form-group">
        <label for="checkout">Check-out Date</label>
        <input type="date" 
               name="checkout" 
               id="checkout"
               value="<?php echo htmlspecialchars($form_data['checkout'] ?? ''); ?>"
               class="<?php echo isset($errors['checkout']) ? 'error' : ''; ?>"
               required>
        <?php if (isset($errors['checkout'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['checkout']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Number of Guests -->
    <div class="form-group">
        <label for="guests">Number of Guests</label>
        <input type="number" 
               name="guests" 
               id="guests"
               min="1" 
               max="10"
               value="<?php echo htmlspecialchars($form_data['guests'] ?? '1'); ?>"
               class="<?php echo isset($errors['guests']) ? 'error' : ''; ?>"
               required>
        <?php if (isset($errors['guests'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['guests']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Special Requests -->
    <div class="form-group">
        <label for="special_requests">Special Requests</label>
        <textarea name="special_requests" 
                  id="special_requests"
                  rows="4"
                  class="<?php echo isset($errors['special_requests']) ? 'error' : ''; ?>"><?php echo htmlspecialchars($form_data['special_requests'] ?? ''); ?></textarea>
        <?php if (isset($errors['special_requests'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['special_requests']); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Requested Date/Time -->
    <div class="form-group">
        <label for="requested_at">Preferred Contact Time</label>
        <input type="datetime-local" 
               name="requested_at" 
               id="requested_at"
               value="<?php echo htmlspecialchars($form_data['requested_at'] ?? ''); ?>"
               class="<?php echo isset($errors['requested_at']) ? 'error' : ''; ?>"
               required>
        <?php if (isset($errors['requested_at'])): ?>
            <div class="error-tooltip">
                <?php echo htmlspecialchars($errors['requested_at']); ?>
            </div>
        <?php endif; ?>
    </div>

    <button type="submit" class="submit-btn">Book Now</button>
</form>

  <footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-column">
                <h3>Oakland</h3>
                <p>Your home away from home, offering comfort and hospitality in the heart of the city.</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
            <div class="footer-column">
                <h3>Quick Links</h3>
                <ul class="footer-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="rooms.html">Rooms & Amenities</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Contact Info</h3>
                <ul class="footer-links">
                    <li><i class="fas fa-map-marker-alt"></i> 123 Peaceful Lane, Cityville</li>
                    <li><i class="fas fa-phone"></i> (555) 123-4567</li>
                    <li><i class="fas fa-envelope"></i> hello@Oakland.com</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2023 Oakland Guest House. All Rights Reserved.</p>
        </div>
    </div>
  </footer>
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
  <script>
    // Remove error class when user starts typing
document.querySelectorAll('input, select, textarea').forEach(field => {
    field.addEventListener('input', function() {
        this.classList.remove('error');
        const tooltip = this.parentNode.querySelector('.error-tooltip');
        if (tooltip) tooltip.remove();
    });
    
    field.addEventListener('change', function() {
        this.classList.remove('error');
        const tooltip = this.parentNode.querySelector('.error-tooltip');
        if (tooltip) tooltip.remove();
    });
});

    document.getElementById('booking-form')?.addEventListener('submit', function(e){
  const checkin = new Date(this.requested_at.value);
  const now = new Date();
  if (checkin < now) { e.preventDefault(); alert('Date must be in the future'); return; }
});
    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        
        if (menuToggle && navLinks) {
            menuToggle.addEventListener('click', function() {
                navLinks.classList.toggle('active');
                
                // Toggle icon
                const icon = menuToggle.querySelector('i');
                if (navLinks.classList.contains('active')) {
                    icon.classList.remove('fa-bars');
                    icon.classList.add('fa-times');
                } else {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            });
            
            // Close menu when clicking links
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    const icon = menuToggle.querySelector('i');
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                });
            });
        }

        // Add shadow to header on scroll
        window.addEventListener('scroll', () => {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
            } else {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            }
        });
    });
  </script>
  <style>
.form-group {
    position: relative;
    margin-bottom: 25px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: var(--primary-color);
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 1rem;
    transition: all 0.3s ease;
    font-family: inherit;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: var(--secondary-color);
    outline: none;
    box-shadow: 0 0 0 3px rgba(58, 124, 165, 0.1);
}

.form-group input.error,
.form-group select.error,
.form-group textarea.error {
    border-color: #dc2626;
    background-color: #fef2f2;
}

.error-tooltip {
    position: absolute;
    top: 100%;
    left: 0;
    background: #dc2626;
    color: white;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 0.875rem;
    margin-top: 4px;
    z-index: 10;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    white-space: nowrap;
}

.error-tooltip::before {
    content: '';
    position: absolute;
    top: -6px;
    left: 15px;
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-bottom: 6px solid #dc2626;
}

.submit-btn {
    width: 100%;
    background: var(--primary-color);
    color: var(--white-color);
    border: none;
    padding: 15px 30px;
    border-radius: 10px;
    font-size: 1.1rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.submit-btn:hover {
    background: var(--primary-600);
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(10, 36, 99, 0.3);
}
</style>
</body>
</html>