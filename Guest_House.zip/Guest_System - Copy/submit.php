<?php
require __DIR__ . '/config.php'; // must session_start() inside config.php

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// --- Rate limiting (per session) ---
if (time() - ($_SESSION['last_booking_time'] ?? 0) < 5) {
    echo "
    <div style='
        margin:50px auto;
        max-width:400px;
        padding:20px;
        font-family:sans-serif;
        color:#721c24;
        background:#f8d7da;
        border:1px solid #f5c6cb;
        border-radius:8px;
        text-align:center;
    '>
        ⏳ Please wait 5 seconds before making another booking.
    </div>
    ";
    exit;
}
$_SESSION['last_booking_time'] = time();

// --- CSRF check ---
if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die('Invalid request (CSRF).');
}
// consume token (single-use)
unset($_SESSION['csrf_token']);

// --- Helper: server-side validation function ---
function validateBooking(array $data) {
    $errors = [];

    // Trim & basic sanitize
    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $room_type = trim($data['room_type'] ?? '');
    $requested_at_raw = trim($data['requested_at'] ?? '');

    $errors = []; // at the top of submit.php

// Phone validation
if (!preg_match('/^[0-9+\-\s\(\)]{6,30}$/', $phone)) {
    $errors['phone'] = 'Invalid phone number.';
}

// Name validation
if ($name === '' || !preg_match('/^[\p{L}\s\'\-\.]{2,100}$/u', $name)) {
    $errors['name'] = 'Invalid name (2-100 letters allowed).';
}

// Email validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Invalid email address.';
}

// Room type validation
$allowed_rooms = ['Deluxe','Standard','Suite','Family','Double'];
if ($room_type === '' || !in_array($room_type, $allowed_rooms, true)) {
    $errors['room_type'] = 'Invalid room type selected.';
}

// Date/time validation
$dt = false;
if ($requested_at_raw !== '') {
    $requested_at_raw = str_replace(' ', 'T', $requested_at_raw);
    try { $dt = new DateTime($requested_at_raw); } 
    catch (Exception $e) { $dt = false; }
}
if (!$dt || $dt < new DateTime('now')) {
    $errors['requested_at'] = 'Invalid or past date/time.';
}


    // Date/time: accept HTML datetime-local value (e.g. 2025-09-30T14:30)
    $dt = false;
    if ($requested_at_raw !== '') {
        // Replace space with T if necessary, allow both formats
        $requested_at_raw = str_replace(' ', 'T', $requested_at_raw);
        try {
            $dt = new DateTime($requested_at_raw);
        } catch (Exception $e) {
            $dt = false;
        }
    }
    if (!$dt) {
        $errors[] = 'Invalid date/time.';
    } else {
        $now = new DateTime('now');
        if ($dt < $now) {
            $errors[] = 'Requested date/time must be in the future.';
        }
    }

    return [
        'ok' => empty($errors),
        'errors' => $errors,
        'clean' => [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'room_type' => $room_type,
            'requested_at' => $dt ? $dt->format('Y-m-d H:i:s') : null
        ]
    ];
}

// --- Validate input ---
$validation = validateBooking($_POST);
if (!$validation['ok']) {
    // show errors (in production return to form with messages)
    foreach ($validation['errors'] as $err) {
        echo "<p style='color:red;'>".htmlspecialchars($err)."</p>";
    }
    echo '<p><a href="javascript:history.back()">Go Back</a></p>';
    exit;
}

$clean = $validation['clean'];

// --- Insert using prepared statements (prevents SQL injection) ---
try {
    $stmt = $pdo->prepare("INSERT INTO bookings (room_type, name, phone, email, requested_at) VALUES (:room, :name, :phone, :email, :requested_at)");
    $stmt->execute([
        ':room' => $clean['room_type'],
        ':name' => $clean['name'],
        ':phone' => $clean['phone'],
        ':email' => $clean['email'],
        ':requested_at' => $clean['requested_at'],
    ]);
    $insertedId = $pdo->lastInsertId();
} catch (Exception $e) {
    // log server-side, but show friendly error to user
    error_log("DB insert failed: " . $e->getMessage());
    die('An internal error occurred. Please try again later.');
}

// --- Optional: send email notification (uses mail(); for local testing use PHPMailer) ---
$admin_email = $admin_email ?? 'yourname@yourdomain.com'; // ensure set in config.php
$subject = "New Booking (#{$insertedId}) - {$clean['room_type']}";
$message = "New booking received:\n\n"
         . "Room: {$clean['room_type']}\n"
         . "Name: {$clean['name']}\n"
         . "Phone: {$clean['phone']}\n"
         . "Email: {$clean['email']}\n"
         . "Requested at: {$clean['requested_at']}\n"
         . "Submitted at: " . date('Y-m-d H:i:s') . "\n";
$headers = "From: no-reply@yourdomain.com\r\nReply-To: {$clean['email']}\r\nX-Mailer: PHP/".phpversion();

// Use @ to suppress on dev; in production log failures
@mail($admin_email, $subject, $message, $headers);

// --- Redirect to a styled thank-you page ---
header('Location: thanks.php?booked=1');
exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You - Oakland</title>
    <link rel="stylesheet" href="CSS/style.css">
    <!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <a href="index.html" class="logo">Oakland</a>
                <div class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="rooms.html">Rooms & Amenities</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section style="padding: 160px 0;">
        <div class="container">
            <div style="max-width: 1600px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;">
                <div style="font-size: 4rem; color: var(--accent-color); margin-bottom: 20px;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h1 style="color: var(--navy-blue); margin-bottom: 15px;">Thank You!</h1>
                <p style="font-size: 1.2rem; color: var(--gray); margin-bottom: 30px;">
                    Your booking request has been received successfully.
                </p>
                <p style="margin-bottom: 30px; color: var(--black-color);">
                    We'll contact you within 24 hours to confirm your reservation. 
                    You'll receive an email confirmation shortly.
                </p>
                
                <div style="background: var(--light-color); padding: 25px; border-radius: 8px; margin-bottom: 30px;">
                    <h3 style="color: var(--navy-blue); margin-bottom: 15px;">
                        <i class="fas fa-info-circle" style="margin-right: 8px;"></i>
                        What Happens Next?
                    </h3>
                    <div style="text-align: left; display: inline-block;">
                        <p style="margin: 10px 0;"><i class="fas fa-envelope" style="color: var(--secondary-color); margin-right: 10px;"></i> Email confirmation within 1 hour</p>
                        <p style="margin: 10px 0;"><i class="fas fa-phone" style="color: var(--secondary-color); margin-right: 10px;"></i> Phone confirmation within 24 hours</p>
                        <p style="margin: 10px 0;"><i class="fas fa-credit-card" style="color: var(--secondary-color); margin-right: 10px;"></i> Payment details sent via email</p>
                    </div>
                </div>

                <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                    <a href="index.html" class="btn" style="background: var(--navy-blue);">
                        <i class="fas fa-home" style="margin-right: 8px;"></i>
                        Back to Home
                    </a>
                    <a href="rooms.html" class="btn">
                        <i class="fas fa-bed" style="margin-right: 15px;"></i>
                        View More Rooms
                    </a>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>Oakland</h3>
                    <p>Your home away from home, offering comfort and hospitality in the heart of the city.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="rooms.html">Rooms & Amenities</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Contact Info</h3>
                    <ul class="footer-links">
                        <li><i class="fas fa-map-marker-alt"></i> 123 Peaceful Lane, Cityville</li>
                        <li><i class="fas fa-phone"></i> (555) 123-4567</li>
                        <li><i class="fas fa-envelope"></i> hello@serenestay.com</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2023 Oakland Guest House. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        
    
        // Mobile menu toggle
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');

        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });

        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
            });
        });

        // Add shadow to header on scroll
        window.addEventListener('scroll', () => {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
            } else {
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            }
        });
        </script>
    
</body>
</html>