<?php
require __DIR__ . '/../config.php';

// Admin guard: check if logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../secure_login.php");
    exit;
}


// Fetch all bookings (latest first)
$stmt = $pdo->query("SELECT * FROM bookings ORDER BY id DESC");
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Oakland</title>
  <link rel="stylesheet" href="../CSS/style.css">
  <link rel="stylesheet" href="../CSS/admin-dashboard.css">
  <!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <a href="../index.html" class="logo">Oakland</a>
                <div class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </div>
                <ul class="nav-links">
                    <li><a href="secure_login.php">Home</a></li>
                    <li><a href="dashboard.php" class="active">Dashboard</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
        
    </header>

    <section class="admin-dashboard-section">
        <div class="container">
            <div class="dashboard-card">
                <div class="dashboard-header">
                    <h1 class="dashboard-title">Booking Requests</h1>
                    <div class="dashboard-actions">
                        <a href="logout.php" class="btn btn-logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                        <a href="dashboard.php" class="btn btn-refresh">
                            <i class="fas fa-redo"></i> Refresh
                        </a>
                    </div>
                </div>

                <?php if (empty($bookings)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No bookings yet</h3>
                        <p>When guests make bookings, they will appear here.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="bookings-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Room Type</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Requested At</th>
                                    <th>Submitted On</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bookings as $b): ?>
                                    <tr class="booking-row">
                                        <td class="booking-id"><?= (int)$b['id'] ?></td>
                                        <td class="room-type">
                                            <span class="room-badge"><?= htmlspecialchars($b['room_type']) ?></span>
                                        </td>
                                        <td class="guest-name"><?= htmlspecialchars($b['name']) ?></td>
                                        <td class="guest-phone"><?= htmlspecialchars($b['phone']) ?></td>
                                        <td class="guest-email">
                                            <a href="mailto:<?= htmlspecialchars($b['email']) ?>">
                                                <?= htmlspecialchars($b['email']) ?>
                                            </a>
                                        </td>
                                        <td class="requested-date"><?= htmlspecialchars($b['requested_at']) ?></td>
                                        <td class="submitted-date"><?= htmlspecialchars($b['created_at']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="booking-stats">
                        <p>Total Bookings: <strong><?= count($bookings) ?></strong></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.querySelector('.menu-toggle');
            const navLinks = document.querySelector('.nav-links');
            
            if (menuToggle && navLinks) {
                menuToggle.addEventListener('click', function() {
                    navLinks.classList.toggle('active');
                    
                    const icon = menuToggle.querySelector('i');
                    if (navLinks.classList.contains('active')) {
                        icon.classList.remove('fa-bars');
                        icon.classList.add('fa-times');
                    } else {
                        icon.classList.remove('fa-times');
                        icon.classList.add('fa-bars');
                    }
                });
                
                document.querySelectorAll('.nav-links a').forEach(link => {
                    link.addEventListener('click', () => {
                        navLinks.classList.remove('active');
                        const icon = menuToggle.querySelector('i');
                        icon.classList.remove('fa-times');
                        icon.classList.add('fa-bars');
                    });
                });
            }

            window.addEventListener('scroll', () => {
                const header = document.querySelector('header');
                if (window.scrollY > 50) {
                    header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
                } else {
                    header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
                }
            });
        });
    </script>
</body>
</html>