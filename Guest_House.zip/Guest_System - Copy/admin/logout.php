
<?php
require __DIR__ . '/../config.php';
session_start();
session_unset();
session_destroy();
header("Location: ../secure_login.php");
exit;
?>