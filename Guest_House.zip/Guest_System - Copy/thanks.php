<?php require __DIR__ . '/config.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You - Oakland Hotel</title>
  <link rel="stylesheet" href="css/style.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400;500;700&family=Montserrat:wght@500;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <a href="index.html" class="logo">Oakland</a>
                <div class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="rooms.html">Rooms & Amenities</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="thank-you-section">
        <div class="container">
            <div class="thank-you-card">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h1 class="thank-you-title">Thank You!</h1>
                <p class="thank-you-message">Your booking request has been received.</p>
                <p class="confirmation-message">We'll contact you shortly to confirm your reservation.</p>
                <a href="index.html" class="home-button">Back to Home</a>
            </div>
        </div>
    </section>
  <style>
     .thank-you-section {
            padding: 120px 0;
            background: linear-gradient(135deg, var(--white-color) 0%, var(--gray-color) 100%);
            min-height: 80vh;
            display: flex;
            align-items: center;
        }

        .thank-you-card {
            background: var(--white-color);
            padding: 60px 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 500px;
            margin: 0 auto;
            position: relative;
        }

        .thank-you-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--accent-color), var(--secondary-color));
            border-radius: 20px 20px 0 0;
        }

        .success-icon {
            font-size: 4rem;
            color: #10B981;
            margin-bottom: 30px;
        }

        .thank-you-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 20px;
            font-family: 'Playfair Display', serif;
        }

        .thank-you-message {
            font-size: 1.2rem;
            color: var(--black-color);
            margin-bottom: 15px;
            line-height: 1.6;
        }

        .confirmation-message {
            font-size: 1rem;
            color: var(--black-color);
            opacity: 0.8;
            margin-bottom: 40px;
            line-height: 1.6;
        }

        .home-button {
            display: inline-block;
            background: var(--primary-color);
            color: var(--white-color);
            padding: 15px 40px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            font-family: 'Montserrat', sans-serif;
        }

        .home-button:hover {
            background: var(--primary-600);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(10, 36, 99, 0.3);
        }

        @media (max-width: 768px) {
            .thank-you-section {
                padding: 80px 0;
            }
            
            .thank-you-card {
                padding: 40px 25px;
                margin: 0 20px;
            }
            
            .thank-you-title {
                font-size: 2rem;
            }
            
            .success-icon {
                font-size: 3rem;
            }}
  </style>
   </body>
   </html>  