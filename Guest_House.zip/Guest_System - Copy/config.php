<?php
// config.php
session_start();
$admin_email = 'you@domain.com';


// DB credentials
$db_host = "localhost";
$db_name = "hotel_app";
$db_user = "booking_user";
$db_pass = "OakHotelApp#2025";



try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()));
}

// CSRF Token setup
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
/**
 * Email Settings
 */
$notify_to   = "you@example.com";       // where admin gets notifications
$notify_from = "no-reply@yourdomain.com"; // sender address
?>